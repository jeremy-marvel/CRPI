var searchData=
[
  ['vertical_5fpan',['vertical_pan',['../ur5__control_8cpp.html#a715e713702c1940bc3b56d92ba1a50ac',1,'vertical_pan(CrpiRobot&lt; CrpiUniversal &gt; *arm, robotPose &amp;pose, double stepSize1, double stepSize2, double max_x, int *stepCount, double *searchTime):&#160;ur5_control.cpp'],['../ur5__control_8h.html#a715e713702c1940bc3b56d92ba1a50ac',1,'vertical_pan(CrpiRobot&lt; CrpiUniversal &gt; *arm, robotPose &amp;pose, double stepSize1, double stepSize2, double max_x, int *stepCount, double *searchTime):&#160;ur5_control.cpp']]]
];
