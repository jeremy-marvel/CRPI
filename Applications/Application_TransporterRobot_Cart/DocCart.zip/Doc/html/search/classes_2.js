var searchData=
[
  ['task_5fargs',['task_args',['../structtask__args.html',1,'']]]
];
