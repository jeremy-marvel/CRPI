var searchData=
[
  ['goal_5fbuf',['goal_buf',['../classcart__status.html#a4912ff0b77258f77f4f7c118ad8345c7',1,'cart_status']]],
  ['goal_5flist',['goal_list',['../structconfig__data.html#ad5378ccb37d95d996823422eee9dc9fc',1,'config_data::goal_list()'],['../classcart__config.html#ac484fbaf3da5c3fcbf6b0b338ebf7812',1,'cart_config::goal_list()']]]
];
